from django.contrib import admin
from django.conf import settings
from .models import *

# Register your models here.
class TruckAdmin(admin.ModelAdmin):
    list_display = ('applicant', 'latitude', 'longitude','category')
    search_fields = ('applicant',)

    fieldsets = (
        (None, {
            'fields': ( 'applicant', 'latitude', 'longitude','category')
        }),
    )

    class Media:
        if hasattr(settings, 'GOOGLE_MAPS_API_KEY') and settings.GOOGLE_MAPS_API_KEY:
            css = {
                'all': ('css/admin/location_picker.css',),
            }
            js = (
                'https://maps.googleapis.com/maps/api/js?key={}'.format(settings.GOOGLE_MAPS_API_KEY),
                'js/admin/location_picker.js',
            )


class FoodTruckAdmin(admin.ModelAdmin):
    list_display = ('category', 'fooditems', 'address','openingtime','closingtime')


class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name']


admin.site.register(Truck, TruckAdmin )
admin.site.register(FoodTruck, FoodTruckAdmin )
admin.site.register(Category, CategoryAdmin )