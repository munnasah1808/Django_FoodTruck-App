from django.shortcuts import render, redirect, get_object_or_404, HttpResponseRedirect
from .models import *
from .forms import *
# Create your views here.

def index(request):
    products = None
    categories = Category.get_all_categories()
    categoryID = request.GET.get('category')
    if categoryID:
        products = FoodTruck.get_all_foodtrucks_by_categoryid(categoryID)
    else:
        products = FoodTruck.get_all_foodtrucks()

    data = {}
    data['products'] = products
    data['categories'] = categories
    return render(request, 'foodapp/index.html', data)


def searchMatch(query, item):
    if item.category:
        return True
    else:
        return False

def search(request):
    query= request.GET.get('search')
    allProds = []
    catprods = FoodTruck.objects.values('category', 'id')
    cats = {item['category'] for item in catprods}
    for cat in cats:
        prodtemp = FoodTruck.objects.filter(category=cat)
        prod=[item for item in prodtemp if searchMatch(query, item)]
    params = {'allProds': allProds}
    return render(request, 'foodapp/search.html', params)



def FoodTruckList(request):
    food_list=FoodTruck.objects.all()
    return render(request,'foodapp/foodtrucklist.html',{'food_list':food_list})



def AddShowTruck(request):
    if request.method == 'POST':
        form = FoodTruckForm(request.POST)
        if form.is_valid():
            form.save()
            form = FoodTruckForm()

            
    else:
        form = FoodTruckForm()
    stud = FoodTruck.objects.all()
    return render(request,'foodapp/Addfoodtruck.html',{'form':form,'stud':stud})



    
def UpdateTrucklist1(request,pk,model,cls):
    item=get_object_or_404(model,pk=pk)
    if request.method=='POST':
        form=cls(request.POST,instance=item)
        if form.is_valid():
            form.save()
            return redirect('index')
    else:
        form=cls(instance=item)
        return render(request, 'foodapp/Updatetrucklist.html', {'form' : form})

def UpdateTrucklists(request, pk):
    return UpdateTrucklist1(request, pk, FoodTruck, FoodTruckForm)




def delete_foodtruck(request, pk):
    template = 'foodapp/foodtrucklist.html'
    FoodTruck.objects.filter(id=pk).delete()
    items = FoodTruck.objects.all()
    context = {
        'items': items,
    }
    return render(request, template, context)