from django.db import models
from django.urls import reverse

class Category(models.Model):
    name = models.CharField(max_length=20)

    @staticmethod
    def get_all_categories():
        return Category.objects.all()


    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse("UpdateTrucklist", kwargs={"id":self.id})

class Truck(models.Model):
    """
    Truck model
    
    Applicant: the name of the truck
    Latitude: Latitude of the truck location
    Longitude: Longitude of the truck location
    Category: Category of food served
    """

    applicant = models.CharField(max_length=250)
    latitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    longitude = models.DecimalField(max_digits=9, decimal_places=6, null=True, blank=True)
    category = models.CharField(max_length=250)

    




class FoodTruck(models.Model):
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    fooditems =  models.CharField(max_length=64)
    address = models.CharField(max_length=512, blank=True, null=True)
    openingtime = models.TimeField(auto_now=False, auto_now_add=False)
    closingtime = models.TimeField(auto_now=False, auto_now_add=False)
    image = models.ImageField(upload_to='uploads/images/',blank=True)


    @staticmethod
    def get_foodtrucks_by_id(ids):
        return FoodTruck.objects.filter(id__in =ids)

    @staticmethod
    def get_all_foodtrucks():
        return FoodTruck.objects.all()

    @staticmethod
    def get_all_foodtrucks_by_categoryid(category_id):
        if category_id:
            return FoodTruck.objects.filter(category = category_id)
        else:
            return FoodTruck.get_all_products()
