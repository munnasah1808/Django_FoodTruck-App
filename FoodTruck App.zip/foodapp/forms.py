from django import forms
from .models import FoodTruck

class FoodTruckForm(forms.ModelForm):
    class Meta:
        model = FoodTruck
        fields = ['category','address','openingtime','closingtime']
        widgets = {
            'category' : forms.TextInput(attrs={'class':'form-control'}),
            'address' : forms.TextInput(attrs={'class':'form-control'}),
            'openingtime' : forms.TextInput(attrs={'class':'form-control'}),
            'closingtime' : forms.TextInput(attrs={'class':'form-control'}),
        }