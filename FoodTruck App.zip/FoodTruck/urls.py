from django.conf.urls import url
from django.contrib import admin
from foodapp import views
from django.conf.urls.static import static
from . import settings

urlpatterns = [
url(r'^admin/', admin.site.urls),
url(r'^$', views.index, name='index'),
url(r'^foodapp/search/', views.search,name='Search'),
url(r'^list/', views.FoodTruckList,name='FoodTruckList'),
url(r'^add/', views.AddShowTruck,name="AddShowTruck"),
url(r'^update/(?P<pk>\d+)$', views.UpdateTrucklists, name="UpdateTrucklist"),
url(r'^delete/(?P<pk>\d+)$', views.delete_foodtruck, name="Deletefoodtruck"),

] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)